package com.example.notificationscheduler;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private JobScheduler mScheduler;
    private static final int JOB_ID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button scheduleButton = findViewById(R.id.scheduleButton);
        Button cancelButton = findViewById(R.id.cancelButton);
        SeekBar seekBar = findViewById(R.id.seekBar);
        TextView seekBarProgress = findViewById(R.id.seekBarProgress);

        scheduleButton.setOnClickListener(v -> scheduleJob());
        cancelButton.setOnClickListener(v -> cancelJobs());

        // Set up SeekBar
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress > 0) {
                    seekBarProgress.setText(progress + " s");
                } else {
                    seekBarProgress.setText(getString(R.string.not_set));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void scheduleJob() {
        RadioGroup networkOptions = findViewById(R.id.networkOptions);
        Switch deviceIdle = findViewById(R.id.idleSwitch);
        Switch deviceCharging = findViewById(R.id.chargingSwitch);
        SeekBar seekBar = findViewById(R.id.seekBar);

        int selectedNetworkId = networkOptions.getCheckedRadioButtonId();
        int selectedNetworkOption = JobInfo.NETWORK_TYPE_NONE;

        if (selectedNetworkId == R.id.noNetwork) {
            selectedNetworkOption = JobInfo.NETWORK_TYPE_NONE;
        } else if (selectedNetworkId == R.id.anyNetwork) {
            selectedNetworkOption = JobInfo.NETWORK_TYPE_ANY;
        } else if (selectedNetworkId == R.id.wifiNetwork) {
            selectedNetworkOption = JobInfo.NETWORK_TYPE_UNMETERED;
        }

        mScheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);

        ComponentName componentName = new ComponentName(this, NotificationJobService.class);
        JobInfo.Builder builder = new JobInfo.Builder(JOB_ID, componentName)
                .setRequiredNetworkType(selectedNetworkOption)
                .setRequiresDeviceIdle(deviceIdle.isChecked())
                .setRequiresCharging(deviceCharging.isChecked());

        // Add deadline constraint if set
        int seekBarProgress = seekBar.getProgress();
        boolean seekBarSet = seekBarProgress > 0;
        if (seekBarSet) {
            builder.setOverrideDeadline(seekBarProgress * 1000L);
        }

        // Check if at least one constraint is set
        boolean constraintSet = selectedNetworkOption != JobInfo.NETWORK_TYPE_NONE ||
                deviceIdle.isChecked() ||
                deviceCharging.isChecked() ||
                seekBarSet;

        if (constraintSet) {
            JobInfo jobInfo = builder.build();
            mScheduler.schedule(jobInfo);
            Toast.makeText(this, R.string.job_scheduled, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.no_constraint_toast, Toast.LENGTH_SHORT).show();
        }
    }

    private void cancelJobs() {
        if (mScheduler != null) {
            mScheduler.cancelAll();
            mScheduler = null;
            Toast.makeText(this, R.string.jobs_cancelled, Toast.LENGTH_SHORT).show();
        }
    }
} 