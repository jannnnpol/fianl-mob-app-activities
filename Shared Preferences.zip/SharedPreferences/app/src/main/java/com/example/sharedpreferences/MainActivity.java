package com.example.sharedpreferences;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private int mCount = 0;
    private int mColor;
    private TextView mShowCount;
    private View mainLayout;

    private SharedPreferences mPreferences;
    private final String sharedPrefFile = "com.example.hellosharedprefs";
    private final String COUNT_KEY = "count";
    private final String COLOR_KEY = "color";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mShowCount = findViewById(R.id.count_textview);
        mainLayout = findViewById(R.id.main_layout);

        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        mCount = mPreferences.getInt(COUNT_KEY, 0);
        mColor = mPreferences.getInt(COLOR_KEY, getResources().getColor(R.color.default_background));

        mShowCount.setText(String.valueOf(mCount));
        mainLayout.setBackgroundColor(mColor);

        findViewById(R.id.count_button).setOnClickListener(v -> {
            mCount++;
            mShowCount.setText(String.valueOf(mCount));
        });

        findViewById(R.id.red_button).setOnClickListener(v -> changeBackground(Color.RED));
        findViewById(R.id.blue_button).setOnClickListener(v -> changeBackground(Color.BLUE));
        findViewById(R.id.green_button).setOnClickListener(v -> changeBackground(Color.GREEN));

        findViewById(R.id.reset_button).setOnClickListener(v -> {
            mCount = 0;
            mShowCount.setText("0");
            mColor = getResources().getColor(R.color.default_background);
            mainLayout.setBackgroundColor(mColor);

            SharedPreferences.Editor editor = mPreferences.edit();
            editor.clear();
            editor.apply();
        });
    }

    private void changeBackground(int color) {
        mColor = color;
        mainLayout.setBackgroundColor(mColor);
    }

    @Override
    protected void onPause() {
        super.onPause();
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.putInt(COUNT_KEY, mCount);
        editor.putInt(COLOR_KEY, mColor);
        editor.apply();
    }
}