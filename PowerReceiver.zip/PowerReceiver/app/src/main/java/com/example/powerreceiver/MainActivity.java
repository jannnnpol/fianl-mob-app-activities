package com.example.powerreceiver;

import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.content.Context;

public class MainActivity extends AppCompatActivity {
    private CustomReceiver customReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        customReceiver = new CustomReceiver();

        // Intent filter for power events
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        registerReceiver(customReceiver, filter);

        // Intent filter for custom broadcast
        IntentFilter customFilter = new IntentFilter(CustomReceiver.CUSTOM_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(customReceiver, customFilter);

        // Set up button
        Button button = findViewById(R.id.send_broadcast_button);
        button.setOnClickListener(this::sendCustomBroadcast);
    }

    public void sendCustomBroadcast(View view) {
        Intent customIntent = new Intent(CustomReceiver.CUSTOM_ACTION);
        LocalBroadcastManager.getInstance(this).sendBroadcast(customIntent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(customReceiver);
        LocalBroadcastManager.getInstance(this).unregisterReceiver(customReceiver);
    }
}
